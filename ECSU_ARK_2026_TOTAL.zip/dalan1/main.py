from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.middleware.cors import CORSMiddleware
import os, zipfile, shutil

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"])

# Пути
TARGET_DIR = os.path.join(os.environ.get('USERPROFILE'), "Desktop", "ECSU DALAN", "dalan1")
EXPORT_NAME = "ECSU_ARK_2026_TOTAL.zip"

@app.websocket("/ws")
async def websocket_endpoint(websocket: WebSocket):
    await websocket.accept()
    await websocket.send_text("--- ЕЦСУ: РЕЖИМ ТОТАЛЬНОЙ МИГРАЦИИ ---")
    while True:
        try:
            data = await websocket.receive_text()
            cmd = data.lower().strip()
            
            if cmd == "export":
                await websocket.send_text("📦 НАЧАЛО СБОРА ВСЕЙ СИСТЕМЫ...")
                with zipfile.ZipFile(EXPORT_NAME, 'w', zipfile.ZIP_DEFLATED) as zipf:
                    # Упаковываем Ядро и Студию
                    zipf.write("main.py")
                    zipf.write("dashboard.html")
                    if os.path.exists("requirements.txt"): zipf.write("requirements.txt")
                    
                    # Упаковываем модули Далан-1
                    if os.path.exists(TARGET_DIR):
                        for root, dirs, files in os.walk(TARGET_DIR):
                            for file in files:
                                file_path = os.path.join(root, file)
                                arcname = os.path.relpath(file_path, os.path.dirname(TARGET_DIR))
                                zipf.write(file_path, arcname)
                        await websocket.send_text(f"✅ Модули Далан-1 добавлены в архив.")
                
                await websocket.send_text(f"🚀 МИГРАЦИОННЫЙ ПАКЕТ ГОТОВ: {EXPORT_NAME}")
                await websocket.send_text("💿 Теперь этот файл можно залить на GitHub или флешку.")

        except WebSocketDisconnect: break

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)
